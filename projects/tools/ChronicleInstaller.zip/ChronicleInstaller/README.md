# Note for Customers

**DO NOT copy the contents of the Chronicle installation script and commit it into your own package. Instead, please take a dependency on this package. This will allow you to receive updates.**

# ChronicleInstaller

The Chronicle Installer package provides a script for installing the latest version of Chronicle agent.

The installer will attempt to stop and remove `auditd` if it is present on the machine. If the installer fails to stop auditd, it will exit with an error message. However, if the removal fails, the installer will continue on and log an error message.

The installer requires access to the EC2 Metadata service in order to determine the region it is located in. We use that region to pull the presigned S3 url from the control service for the agent RPM. This download is attempted 5 times with an exponential backoff strategy.

The code also contains the public key which is used to verify the download of the agent RPM.

Instructions for use are located on the [wiki](https://w.amazon.com/bin/view/Chronicle/Onboarding/EC2Instance). These instructions include sample commits for how to integrate this package into your deployments.

# Testing
There is a mostly automated testing process with documentation available [here](https://w.amazon.com/bin/view/Chronicle/Internal/InstallerTesting/).


