package org.spapidemo;


import org.spapidemo.*;
import org.spapidemo.auth.*;
import org.spapidemo.model.*;
import org.spapidemo.notification.NotificationsApi;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import com.amazon.SellingPartnerAPIAA.AWSAuthenticationCredentials;
import com.amazon.SellingPartnerAPIAA.AWSAuthenticationCredentialsProvider;
import com.amazon.SellingPartnerAPIAA.LWAAuthorizationCredentials;



public class ClientMain {

    // Credentials Configuration

    static String AccessKeyId = "Your AWS Access Key";
    static String SecretKey = "Your AWS Secret Key";
    static String ClientId = "Your Amazon App Id";
    static String ClientSecret = "Your Amazon App Secret";
    static String RefreshToken = "Your Amazon App RefreshToken";

    /* Spapi Configuration */
    static String AuthEndpoint = "https://api.amazon.com/auth/o2/token";
    static String ApiEndpoint = "https://sellingpartnerapi-na.amazon.com";
    static String IAMRoleArn = "arn:aws:iam::1234xxxxxxxx:role/yourrole";
    static String AccountId = "1234xxxxxxxx";
    static String RegionId = "us-east-1";
    /* Spapi Configuration */

    static AWSAuthenticationCredentials awsCredentials;
    static AWSAuthenticationCredentialsProvider awsCredentialsProvider;
    static LWAAuthorizationCredentials lwaCredentials, lwaCredentialsForSubscription;
    static NotificationsApi apiInstance, apiInstanceForSubscription;
    static String NOTIFICATIONTYPE = "ANY_OFFER_CHANGED";//https://github.com/amzn/selling-partner-api-docs/blob/main/guides/use-case-guides/notifications-use-case-guide-v1.md#notificationtype
    /*
    Notification Type for EventBridge:
    BRANDED_ITEM_CONTENT_CHANGE
    ITEM_PRODUCT_TYPE_CHANGE

    Notification Type for SQS:
    ANY_OFFER_CHANGED
    B2B_ANY_OFFER_CHANGED
    FEE_PROMOTION
    FBA_OUTBOUND_SHIPMENT_STATUS
    FULFILLMENT_ORDER_STATUS
     */


    public static void main(String[] args) {

        awsCredentials = AWSAuthenticationCredentials.builder().accessKeyId(AccessKeyId).secretKey(SecretKey).region(RegionId).build();
        awsCredentialsProvider = AWSAuthenticationCredentialsProvider.builder().roleArn(IAMRoleArn).roleSessionName("spapidemonotificationsession").build();
        lwaCredentials = LWAAuthorizationCredentials.builder()
                .clientId(ClientId)
                .clientSecret(ClientSecret)
                .withScope(com.amazon.SellingPartnerAPIAA.ScopeConstants.SCOPE_NOTIFICATIONS_API)
                .endpoint(AuthEndpoint).build();
        apiInstance = new NotificationsApi.Builder().awsAuthenticationCredentials(awsCredentials).awsAuthenticationCredentialsProvider(awsCredentialsProvider).lwaAuthorizationCredentials(lwaCredentials).endpoint(ApiEndpoint).build();

        lwaCredentialsForSubscription = LWAAuthorizationCredentials.builder()
                .clientId(ClientId)
                .clientSecret(ClientSecret)
                .refreshToken(RefreshToken)
                .endpoint(AuthEndpoint).build();
        apiInstanceForSubscription = new NotificationsApi.Builder().awsAuthenticationCredentials(awsCredentials).awsAuthenticationCredentialsProvider(awsCredentialsProvider).lwaAuthorizationCredentials(lwaCredentialsForSubscription).endpoint(ApiEndpoint).build();

        int Step = 0;

//        Select your step:
//        Step = 1; //Step1 Create EventBridge Destination
//        Step = 2; //Step2 Create SQS Destination
//        Step = 3; //Step3 Create Subscription
//        Step = 4; //Step4 delete Subscription
//        Step = 5; //Step5 delete destination
//        Others: Show destination and subscription information
        switch(Step) {
            case 1:
                createEventBridgeDestination();
                break;
            case 2:
                createSQSDestination();
                break;
            case 3:
                createSubscription();
                break;
            case 4:
                deleteSubscription();
                break;
            case 5:
                deleteDestination();
                break;
            default:
                getDestinationAndSubscription();
                break;
        }
    }

    static void createEventBridgeDestination(){

        CreateDestinationRequest body = new CreateDestinationRequest();
        DestinationResourceSpecification resourceSpec = new DestinationResourceSpecification();
        EventBridgeResourceSpecification event = new EventBridgeResourceSpecification();
        event.setAccountId(AccountId);
        event.setRegion(RegionId);
        resourceSpec.setEventBridge(event);
        body.setName("notificationclient");
        body.setResourceSpecification(resourceSpec);

        try {
            CreateDestinationResponse result = apiInstance.createDestination(body);
            System.out.println(result);
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }
    static void createSQSDestination(){

        CreateDestinationRequest body = new CreateDestinationRequest();
        DestinationResourceSpecification resourceSpec = new DestinationResourceSpecification();
        EventBridgeResourceSpecification event = new EventBridgeResourceSpecification();
        SqsResource sqs = new SqsResource();
        String sqsARN = "arn:aws:sqs:us-east-1:1234xxxxxxxx:sqsname"; //SQS ARN
        sqs.setArn(sqsARN);
        resourceSpec.setSqs(sqs);
        body.setName("notificationclient");
        body.setResourceSpecification(resourceSpec);

        try {
            CreateDestinationResponse result = apiInstance.createDestination(body);
            System.out.println(result);
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

    static void createSubscription(){

        CreateSubscriptionRequest body = new CreateSubscriptionRequest();
        body.setPayloadVersion("1.0");
        String destinationId = "e70bf10d-7d85-4081-a725-xxxxxxxxxx"; //Set your DestinationId created from step 1 or 2.
        body.setDestinationId(destinationId);

        try {
            CreateSubscriptionResponse result = apiInstanceForSubscription.createSubscription(body, NOTIFICATIONTYPE); //Specify your Notification Type
            System.out.println(result);
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

    static void deleteSubscription(){

        try {
            DeleteSubscriptionByIdResponse result = apiInstance.deleteSubscriptionById("your_subscription_id", "ANY_OFFER_CHANGED");
            System.out.println(result);
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

    static void deleteDestination(){

        try {
            DeleteDestinationResponse result = apiInstance.deleteDestination("e70bf10d-7d85-4081-a725-xxxxxxxxxx");
            System.out.println(result);
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

    static void getDestinationAndSubscription(){
        try {
            GetDestinationsResponse destinationResult = apiInstance.getDestinations();
            System.out.println(destinationResult);
            GetSubscriptionResponse subscriptionResult = apiInstanceForSubscription.getSubscription(NOTIFICATIONTYPE); //Specify your Notification Type
            System.out.println(subscriptionResult);
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

}
