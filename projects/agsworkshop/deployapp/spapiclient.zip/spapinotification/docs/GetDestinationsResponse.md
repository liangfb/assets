
# GetDestinationsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**DestinationList**](DestinationList.md) | The payload for the getDestinations operation. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the getDestinations operation. |  [optional]



