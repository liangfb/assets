
# GetSubscriptionByIdResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**Subscription**](Subscription.md) | The payload for the getSubscriptionById operation. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | An unexpected condition occurred during the getSubscriptionById operation. |  [optional]



