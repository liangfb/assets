
# EventBridgeResourceSpecification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**region** | **String** | The AWS region in which you will be receiving the notifications. | 
**accountId** | **String** | The identifier for the AWS account that is responsible for charges related to receiving notifications. | 



