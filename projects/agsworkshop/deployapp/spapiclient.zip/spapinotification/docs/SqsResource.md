
# SqsResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**arn** | **String** | The Amazon Resource Name (ARN) associated with the SQS queue. | 



