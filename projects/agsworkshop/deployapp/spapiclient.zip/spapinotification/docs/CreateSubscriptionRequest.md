
# CreateSubscriptionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payloadVersion** | **String** | The version of the payload object to be used in the notification. |  [optional]
**destinationId** | **String** | The identifier for the destination where notifications will be delivered. |  [optional]



