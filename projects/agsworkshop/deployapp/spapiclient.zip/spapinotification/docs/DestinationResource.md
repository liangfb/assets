
# DestinationResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sqs** | [**SqsResource**](SqsResource.md) | An Amazon Simple Queue Service (SQS) queue destination. |  [optional]
**eventBridge** | [**EventBridgeResource**](EventBridgeResource.md) | An Amazon EventBridge destination. |  [optional]



