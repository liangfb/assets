
# Subscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptionId** | **String** | The subscription identifier generated when the subscription is created. | 
**payloadVersion** | **String** | The version of the payload object to be used in the notification. | 
**destinationId** | **String** | The identifier for the destination where notifications will be delivered. | 



