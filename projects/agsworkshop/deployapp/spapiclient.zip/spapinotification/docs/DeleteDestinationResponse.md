
# DeleteDestinationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the deleteDestination operation. |  [optional]



