
# GetSubscriptionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**Subscription**](Subscription.md) | The payload for the getSubscription operation. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the getSubscription operation. |  [optional]



