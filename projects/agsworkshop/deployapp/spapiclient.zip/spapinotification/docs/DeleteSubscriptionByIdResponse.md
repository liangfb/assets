
# DeleteSubscriptionByIdResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**ErrorList**](ErrorList.md) | An unexpected condition occurred during the deleteSubscriptionById operation. |  [optional]



