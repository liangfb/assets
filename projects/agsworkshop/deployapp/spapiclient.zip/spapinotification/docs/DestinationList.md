
# DestinationList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



