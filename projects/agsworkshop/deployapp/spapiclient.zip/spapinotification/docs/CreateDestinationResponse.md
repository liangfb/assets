
# CreateDestinationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**Destination**](Destination.md) | The payload for the createDestination operation. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the createDestination operation. |  [optional]



