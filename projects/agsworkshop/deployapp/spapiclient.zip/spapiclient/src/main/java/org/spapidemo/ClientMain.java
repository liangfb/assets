package org.spapidemo;

import com.amazon.SellingPartnerAPIAA.AWSAuthenticationCredentials;
import com.amazon.SellingPartnerAPIAA.AWSAuthenticationCredentialsProvider;
import com.amazon.SellingPartnerAPIAA.LWAAuthorizationCredentials;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.spapidemo.*;
import org.spapidemo.auth.*;
import org.spapidemo.model.*;
import org.spapidemo.api.OrdersV0Api;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ClientMain {

    // Credentials Configuration
    static String AccessKeyId = "Your AWS Access Key";
    static String SecretKey = "Your AWS Secret Key";
    static String ClientId = "Your Amazon App Id";
    static String ClientSecret = "Your Amazon App Secret";
    static String RefreshToken = "Your Amazon App RefreshToken";

    /* Spapi Configuration */
    static String RegionId = "us-east-1";
    static String AuthEndpoint = "https://api.amazon.com/auth/o2/token";
    static String ApiEndpoint = "https://sellingpartnerapi-na.amazon.com";
    static String IAMRoleArn = "arn:aws:iam::1234xxxxxxxx:role/yourrole";
    /* Spapi Configuration */

    /* Database configuration */
    static String DatabaseInstance = "jdbc:mysql://<your rds endpoint>/magento";
    static String DbUser = "user";
    static String DbPassword = "password";
    /* Database configuration */

    static AWSAuthenticationCredentials awsCredentials;
    static AWSAuthenticationCredentialsProvider awsCredentialsProvider;
    static LWAAuthorizationCredentials lwaCredentials;
    static OrdersV0Api ordersV0Api;

    public static void main(String[] args) {

        awsCredentials = AWSAuthenticationCredentials.builder().accessKeyId(AccessKeyId).secretKey(SecretKey).region(RegionId).build();
        awsCredentialsProvider = AWSAuthenticationCredentialsProvider.builder().roleArn(IAMRoleArn).roleSessionName("spapidemosession").build();
        lwaCredentials = LWAAuthorizationCredentials.builder().clientId(ClientId).clientSecret(ClientSecret).refreshToken(RefreshToken).endpoint(AuthEndpoint).build();
        ordersV0Api = new OrdersV0Api.Builder().awsAuthenticationCredentials(awsCredentials).awsAuthenticationCredentialsProvider(awsCredentialsProvider).lwaAuthorizationCredentials(lwaCredentials).endpoint(ApiEndpoint).build();

        try {
            List<String> marketplaceIds = Arrays.asList("ATVPDKIKX0DER"); //add marketplace Ids from https://github.com/amzn/selling-partner-api-docs/blob/main/guides/developer-guide/SellingPartnerApiDeveloperGuide.md#marketplaceid-values
            LocalDateTime date = LocalDateTime.now().minusDays(7);
            String startTime = date.format(DateTimeFormatter.ISO_DATE_TIME);
            GetOrdersResponse response = ordersV0Api.getOrders(marketplaceIds, startTime, null,null,null,null,null,null,null,null,null,null,null, null);
            OrderList orders = response.getPayload().getOrders();
            System.out.println("The orders count from API: " + orders.stream().count());
            SaveToDB db = new SaveToDB(DatabaseInstance, DbUser, DbPassword);
            orders.forEach(order->
            {
                System.out.println("OrderId: " + order.getAmazonOrderId() + "OrderDate: " + order.getPurchaseDate() + "Order Total: " + order.getOrderTotal());
                db.saveOrder(order);

            });
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }
}