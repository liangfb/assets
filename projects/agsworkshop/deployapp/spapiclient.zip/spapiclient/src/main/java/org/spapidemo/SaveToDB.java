package org.spapidemo;

import org.spapidemo.model.Order;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SaveToDB {

    String url = "";
    String user = "";
    String password = "";

    Connection conn;

    public SaveToDB(String DbInstance, String User, String Password) {

        url = DbInstance;
        user = User;
        password = Password;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    private Connection getCon() throws Exception{

        conn = DriverManager.getConnection(url, user, password);
        return conn;
    }

    void closeConnection() throws Exception{
        if(!conn.isClosed())
            conn.close();
    }

    static Timestamp getDate(String date){
        date = date.replace("T", " ").replace("Z", "");
        return Timestamp.valueOf(date);
    }

    void saveOrder(Order order) {

        try {
            Connection conn = getCon();
            String sql = "INSERT INTO spapi_order VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt;
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, order.getAmazonOrderId());
            pstmt.setTimestamp(2, getDate(order.getPurchaseDate()));
            pstmt.setTimestamp(3, getDate(order.getLastUpdateDate()));
            pstmt.setString(4, order.getOrderStatus().toString());
            pstmt.setString(5, order.getFulfillmentChannel().toString());
            pstmt.setString(6, order.getSalesChannel());
            pstmt.setString(7, order.getShipServiceLevel());
            pstmt.setString(8, order.getOrderTotal().getCurrencyCode());
            pstmt.setBigDecimal(9, new BigDecimal(order.getOrderTotal().getAmount()));
            pstmt.setInt(10, order.getNumberOfItemsShipped());
            pstmt.setInt(11, order.getNumberOfItemsUnshipped());
            pstmt.setString(12, order.getPaymentMethod().toString());
            pstmt.setString(13, String.join(",", order.getPaymentMethodDetails()));
            pstmt.setBoolean(14, order.isIsReplacementOrder());
            pstmt.setString(15, order.getMarketplaceId());
            pstmt.setString(16, order.getShipmentServiceLevelCategory());
            pstmt.setString(17, order.getOrderType().toString());
            pstmt.setTimestamp(18, getDate(order.getEarliestShipDate()));
            pstmt.setTimestamp(19, getDate(order.getLatestShipDate()));
            pstmt.setTimestamp(20, getDate(order.getEarliestDeliveryDate()));
            pstmt.setTimestamp(21, getDate(order.getLatestDeliveryDate()));
            pstmt.setBoolean(22, order.isIsBusinessOrder());
            pstmt.setBoolean(23, order.isIsPrime());
            pstmt.setBoolean(24, order.isIsGlobalExpressEnabled());
            pstmt.setBoolean(25, order.isIsPremiumOrder());
            pstmt.setBoolean(26, order.isIsSoldByAB());
            pstmt.setString(27, order.getAssignedShipFromLocationAddress().getName());
            pstmt.setString(28, order.getAssignedShipFromLocationAddress().getAddressLine1());
            pstmt.setString(29, order.getAssignedShipFromLocationAddress().getCity());
            pstmt.setString(30, order.getAssignedShipFromLocationAddress().getStateOrRegion());
            pstmt.setString(31, order.getAssignedShipFromLocationAddress().getPostalCode());
            pstmt.setString(32, order.getAssignedShipFromLocationAddress().getCountryCode());
            pstmt.setString(33, order.getAssignedShipFromLocationAddress().getPhone());
            pstmt.setString(34, order.getAssignedShipFromLocationAddress().getAddressType().toString());
            pstmt.setString(35, order.getFulfillmentInstruction().getFulfillmentSupplySourceId());

            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }


}
