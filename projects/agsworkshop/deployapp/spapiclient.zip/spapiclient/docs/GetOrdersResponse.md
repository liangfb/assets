
# GetOrdersResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**OrdersList**](OrdersList.md) | The payload for the getOrders operation. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the getOrders operation. |  [optional]



