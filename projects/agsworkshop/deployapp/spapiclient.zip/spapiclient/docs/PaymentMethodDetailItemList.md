
# PaymentMethodDetailItemList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



