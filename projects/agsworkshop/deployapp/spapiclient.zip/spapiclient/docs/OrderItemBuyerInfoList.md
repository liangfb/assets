
# OrderItemBuyerInfoList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



