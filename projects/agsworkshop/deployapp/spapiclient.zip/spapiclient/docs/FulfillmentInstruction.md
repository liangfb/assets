
# FulfillmentInstruction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fulfillmentSupplySourceId** | **String** | Denotes the recommended sourceId where the order should be fulfilled from. |  [optional]



