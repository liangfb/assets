
# Money

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencyCode** | **String** | The three-digit currency code. In ISO 4217 format. |  [optional]
**amount** | **String** | The currency amount. |  [optional]



