
# PointsGrantedDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pointsNumber** | **Integer** | The number of Amazon Points granted with the purchase of an item. |  [optional]
**pointsMonetaryValue** | [**Money**](Money.md) | The monetary value of the Amazon Points granted. |  [optional]



