
# GetOrderAddressResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**OrderAddress**](OrderAddress.md) | The payload for the getOrderAddress operations. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the getOrderAddress operation. |  [optional]



