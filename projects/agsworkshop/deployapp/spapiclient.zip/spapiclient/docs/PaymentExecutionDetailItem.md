
# PaymentExecutionDetailItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payment** | [**Money**](Money.md) |  | 
**paymentMethod** | **String** | A sub-payment method for a COD order.  Possible values:  * COD - Cash On Delivery.  * GC - Gift Card.  * PointsAccount - Amazon Points. | 



