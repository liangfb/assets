
# GetOrderItemsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**OrderItemsList**](OrderItemsList.md) | The payload for the getOrderItems operation. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the getOrderItems operation. |  [optional]



