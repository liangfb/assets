
# ProductInfoDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberOfItems** | **Integer** | The total number of items that are included in the ASIN. |  [optional]



