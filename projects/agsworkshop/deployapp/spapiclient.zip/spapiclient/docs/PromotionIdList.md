
# PromotionIdList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



