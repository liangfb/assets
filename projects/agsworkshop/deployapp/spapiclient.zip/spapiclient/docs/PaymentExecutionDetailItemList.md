
# PaymentExecutionDetailItemList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



