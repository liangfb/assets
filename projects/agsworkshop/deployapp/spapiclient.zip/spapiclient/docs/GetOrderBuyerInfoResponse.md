
# GetOrderBuyerInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**OrderBuyerInfo**](OrderBuyerInfo.md) | The payload for the getOrderBuyerInfo operations. |  [optional]
**errors** | [**ErrorList**](ErrorList.md) | One or more unexpected errors occurred during the getOrderBuyerInfo operation. |  [optional]



