
# BuyerCustomizedInfoDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customizedURL** | **String** | The location of a zip file containing Amazon Custom data. |  [optional]



